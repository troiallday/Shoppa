<?php

require "connect.inc.php";
//$symptom=$_REQUEST['symptom'];
$return="";
//echo $name.$phone.$password;

$response = array();


			$query2="SELECT * FROM  products";
		$result = $conn->query($query2);
		if ($result->num_rows>0){
			$response["products"] = array();
			while ($rows = $result->fetch_assoc()) {

				$product = array();
				$product['name'] = $rows['name'];
				$product['category'] = $rows['category'];
				$product['price'] = $rows['price'];
				$product['details'] = $rows['details'];
				$product['image1'] = $rows['image1'];
				$product['image2'] = $rows['image2'];
				$product['image3'] = $rows['image3'];
				$product['id'] = $rows['id'];


				// push single product into final response array
        array_push($response["products"], $product);


}
    // success
    $response["success"] = 1;
 
    // echoing JSON response
    echo json_encode($response);
} else {
    // no products found
    $response["success"] = 0;
    $response["message"] = "No products found";
 
    // echo no users JSON
    echo json_encode($response);
}
		




?>