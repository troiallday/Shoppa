<?php

require "connect.inc.php";
//$symptom=$_REQUEST['symptom'];
$return="";
//echo $name.$phone.$password;


			$query2="SELECT * FROM  products";
		$result = $conn->query($query2);
		if ($result->num_rows>0){
			while ($rows = $result->fetch_assoc()) {

				$return .= $rows['price']."<br>";



			}

			
		}else{
				echo"Failed".$conn->error;
			}

echo $return;






?>